import boto3
import json
from datetime import datetime

cognito = boto3.client('cognito-idp')

# Custom JSON encoder to handle datetime objects
class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)
    
# Define the allowed attributes
allowed_attributes = {
    'given_name': 'given_name',
    'family_name': 'family_name',
    'email': 'email',
    'phone_number': 'phone_number',
    'custom:organization': 'custom:organization',
    'custom:role': 'custom:role',
    'UserStatus': 'verification_status'
}

def lambda_handler(event, context):
    http_method = event.get('httpMethod', 'GET')

    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'OPTIONS, GET, POST, PUT, DELETE',
                'Access-Control-Allow-Headers': 'Authorization, Content-Type'
            },
            'body': ''
        }

    headers = event.get('headers', {})
    if 'Authorization' not in headers:
        return {
            'statusCode': 401,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'OPTIONS, GET, POST, PUT, DELETE',
                'Access-Control-Allow-Headers': 'Authorization, Content-Type'
            },
            'body': json.dumps({'error': 'Unauthorized - No Authorization header found'})
        }

    token = headers.get('Authorization')
    params = {'UserPoolId': 'us-east-1_ODcx7VXFP'}

    try:
        if http_method == 'GET':
            response = cognito.list_users(**params)
            
            filtered_users = []
            for user in response['Users']:
                user_data = {}
                user_role = None
                
                for attribute in user['Attributes']:
                    if attribute['Name'] in allowed_attributes:
                        user_data[allowed_attributes[attribute['Name']]] = attribute['Value']
                        if attribute['Name'] == 'custom:role':
                            user_role = attribute['Value']
                
                user_data['verification_status'] = 'Verified' if user['UserStatus'] == 'CONFIRMED' else 'Not Verified'
                
                if ((user_role == 'Trucking Operator')
                    or (user_role == 'Rail Operator')
                    or (user_role == 'Third Party Logistics Provider')):
                    filtered_users.append(user_data)

            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true',
                    'Access-Control-Allow-Methods': 'OPTIONS, GET, POST, PUT, DELETE',
                    'Access-Control-Allow-Headers': 'Authorization, Content-Type'
                },
                'body': json.dumps(filtered_users, cls=CustomJSONEncoder)
            }

        return {
            'statusCode': 405,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'OPTIONS, GET, POST, PUT, DELETE',
                'Access-Control-Allow-Headers': 'Authorization, Content-Type'
            },
            'body': json.dumps({'error': f'Method {http_method} not allowed'})
        }

    except Exception as err:
        print(err)
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
                'Access-Control-Allow-Methods': 'OPTIONS, GET, POST, PUT, DELETE',
                'Access-Control-Allow-Headers': 'Authorization, Content-Type'
            },
            'body': json.dumps({'error': str(err)})
        }
