import boto3
import csv
import os
import json
from io import StringIO
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket_name = record['s3']['bucket']['name']
        file_key = record['s3']['object']['key']
        
        # Get the file metadata to extract creation time
        response = s3.head_object(Bucket=bucket_name, Key=file_key)
        file_creation_time = response['LastModified'].strftime("%Y-%m-%dT%H:%M:%S.%fZ")[:-3] + "Z"

        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        content = response['Body'].read().decode('utf-8')
        
        # Process CSV file
        csv_reader = csv.DictReader(StringIO(content))

        # **Trim whitespace from headers and add new columns**
        cleaned_data = []
        for row in csv_reader:
            cleaned_row = {key.strip(): value.strip() for key, value in row.items()}
            
            # Add new fields
            cleaned_row['createdAt'] = file_creation_time
            cleaned_row['updatedAt'] = file_creation_time
            cleaned_row['bookingStatus'] = 'unassigned'
            cleaned_row['containerStatus'] = 'On-Ship'
            cleaned_row['flag'] = 'FALSE'
            cleaned_row['__typename'] = 'Container'

            cleaned_data.append(cleaned_row)

        table_name = os.environ['DYNAMODB_TABLE']
        table = dynamodb.Table(table_name)
        
        with table.batch_writer() as batch:
            for row in cleaned_data:
                batch.put_item(Item=row)
        
        print(f"Successfully inserted data from {file_key} into {table_name}")
        
    return {
        'statusCode': 200,
        'body': json.dumps('Data import successful')
    }
