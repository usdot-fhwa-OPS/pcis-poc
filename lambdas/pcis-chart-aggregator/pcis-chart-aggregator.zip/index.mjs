// index.mjs (Node.js 24.x friendly) — AWS SDK v3, no GSIs, API Gateway authorizer claims only.

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";

const TABLE_NAME =
  process.env.DDB_TABLE_NAME || process.env.DYNAMODB_TABLE || "Container";

const CAPACITY_TOTAL = process.env.TERMINAL_CAPACITY
  ? parseInt(process.env.TERMINAL_CAPACITY, 10)
  : null;

const client = new DynamoDBClient({});
const ddb = DynamoDBDocumentClient.from(client);

// ---- Helpers ----

async function scanAll(params) {
  const items = [];
  let ExclusiveStartKey;

  do {
    const res = await ddb.send(
      new ScanCommand({
        ...params,
        ExclusiveStartKey,
      })
    );

    items.push(...(res.Items || []));
    ExclusiveStartKey = res.LastEvaluatedKey;
  } while (ExclusiveStartKey);

  return items;
}

function normalizeRole(raw) {
  if (!raw) return "";
  return raw.toString().trim().toLowerCase();
}

function getClaims(event) {
  const authorizer = event?.requestContext?.authorizer;
  // REST API (v1): authorizer.claims
  // HTTP API (v2): authorizer.jwt.claims
  return authorizer?.claims || authorizer?.jwt?.claims || authorizer || null;
}

function getPrimaryRole(claims) {
  const roleClaim = claims?.["custom:role"] || claims?.role;

  const groups =
    claims?.["cognito:groups"] || claims?.groups || claims?.roles;

  if (roleClaim) return normalizeRole(roleClaim);

  if (Array.isArray(groups) && groups.length > 0) return normalizeRole(groups[0]);
  if (typeof groups === "string" && groups.length > 0) return normalizeRole(groups);

  return "";
}

function aggregateForPersona(allItems, primaryRole, claims) {
  const bcoEmailClaim = claims?.["custom:bcoEmail"] || claims?.email;

  // ---- Scope filtering (Phase-1, scan + filter) ----
  // Not as fast as GSIs, but enforces access control.
  let scoped = allItems;

  // BCO should only see their own cargo
  if (
    primaryRole.includes("bco") ||
    primaryRole.includes("beneficial") ||
    primaryRole.includes("cargo")
  ) {
    if (!bcoEmailClaim) {
      return {
        error: { statusCode: 403, message: "Forbidden: missing bco email claim" },
      };
    }
    const target = bcoEmailClaim.toLowerCase();
    scoped = allItems.filter(
      (it) => (it.bcoEmail || "").toLowerCase() === target
    );
  }

  // Transportation/Trucking/Rail operators:
  // Your current DynamoDB item sample does not include operatorId/assignedTo.
  // For Phase-1, we return aggregated metrics without scoping by operator.
  // Once you add operator fields + GSIs, we will enforce scoping here.
  if (
    primaryRole.includes("transport") ||
    primaryRole.includes("truck") ||
    primaryRole.includes("trucking") ||
    primaryRole.includes("rail") ||
    primaryRole.includes("operator")
  ) {
    scoped = allItems;
  }

  // Terminal operator can see terminal-wide data
  if (primaryRole.includes("terminal")) {
    scoped = allItems;
  }

  // ---- Aggregation (chart-ready summaries) ----
  const statusCounts = {};
  const bookingCounts = {};
  const reservationCounts = {};
  const ownerCounts = {};
  const upcomingAppointments = [];

  const now = new Date();
  let occupied = 0;

  for (const it of scoped) {
    // Your table uses containerStatus
    const containerStatus = it.containerStatus || "unknown";
    statusCounts[containerStatus] = (statusCounts[containerStatus] || 0) + 1;

    const bookingStatus = it.bookingStatus || "unknown";
    bookingCounts[bookingStatus] = (bookingCounts[bookingStatus] || 0) + 1;

    const reservationStatus = it.reservationStatus || "unknown";
    reservationCounts[reservationStatus] = (reservationCounts[reservationStatus] || 0) + 1;

    const bcoEmail = (it.bcoEmail || "unknown").toLowerCase();
    ownerCounts[bcoEmail] = (ownerCounts[bcoEmail] || 0) + 1;

    // Capacity approximation: treat On-Dock as occupying capacity
    if (containerStatus.toLowerCase() === "on-dock") occupied += 1;

    // Upcoming within 72 hours: best available time fields you currently have
    const candidateTime =
      it.modifiedReservationDate ||
      it.reservationDate ||
      it.arrivalDate ||
      it.createdAt;

    if (candidateTime) {
      const dt = new Date(candidateTime);
      if (!Number.isNaN(dt.getTime())) {
        const diffHrs = (dt - now) / (1000 * 60 * 60);
        if (diffHrs >= 0 && diffHrs <= 72) {
          upcomingAppointments.push({
            // Your PK is containerID
            containerID: it.containerID || it.containerId || it.id || null,
            when: dt.toISOString(),
            hoursUntil: +diffHrs.toFixed(2),
            containerStatus,
            bookingStatus,
            reservationStatus,
          });
        }
      }
    }
  }

  const capacity = CAPACITY_TOTAL
    ? {
        occupied,
        total: CAPACITY_TOTAL,
        percent: +(occupied / CAPACITY_TOTAL * 100).toFixed(2),
      }
    : { occupied };

  // Persona-specific “plug and play” response shape
  if (primaryRole.includes("terminal")) {
    return {
      capacity,
      statusDistribution: statusCounts,
      approvalQueueSummary: reservationCounts,
      eventsToday: upcomingAppointments.slice(0, 50),
    };
  }

  if (
    primaryRole.includes("transport") ||
    primaryRole.includes("truck") ||
    primaryRole.includes("trucking") ||
    primaryRole.includes("rail") ||
    primaryRole.includes("operator")
  ) {
    return {
      workloadByStatus: bookingCounts,
      decisionSummary: reservationCounts,
      calendarEvents: upcomingAppointments.slice(0, 200),
    };
  }

  // BCO
  return {
    cargoStatus: statusCounts,
    shipmentTimeline: upcomingAppointments.slice(0, 200),
    transportationAssignmentSummary: bookingCounts,
  };
}

// ---- Handler ----

export const handler = async (event) => {
  try {
    const claims = getClaims(event);
    if (!claims) {
      return {
        statusCode: 401,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "Unauthorized: missing authorizer claims" }),
      };
    }

    const primaryRole = getPrimaryRole(claims);
    if (!primaryRole) {
      return {
        statusCode: 403,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: "Forbidden: no role claim present" }),
      };
    }

    const allowed =
      primaryRole.includes("terminal") ||
      primaryRole.includes("transport") ||
      primaryRole.includes("truck") ||
      primaryRole.includes("trucking") ||
      primaryRole.includes("bco") ||
      primaryRole.includes("beneficial") ||
      primaryRole.includes("cargo") ||
      primaryRole.includes("rail") ||
      primaryRole.includes("operator");

    if (!allowed) {
      return {
        statusCode: 403,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: "Forbidden: role not supported",
          role: primaryRole,
        }),
      };
    }

    // Phase-1: scan the table (works now). Replace later with GSI queries.
    const allItems = await scanAll({
      TableName: TABLE_NAME,

      // Optional optimization: reduce read costs by projecting only what you need.
      // Uncomment once you confirm these attribute names exist on all items.
      // ProjectionExpression:
      //   "containerID, containerStatus, bookingStatus, reservationStatus, bcoEmail, arrivalDate, reservationDate, modifiedReservationDate, createdAt",
    });

    const out = aggregateForPersona(allItems, primaryRole, claims);

    if (out?.error) {
      return {
        statusCode: out.error.statusCode,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: out.error.message }),
      };
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ok: true, role: primaryRole, data: out }),
    };
  } catch (err) {
    console.error("Error in pcis-chart-aggregator:", err);
    return {
      statusCode: err.statusCode || 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: err.message || "Internal error" }),
    };
  }
};
